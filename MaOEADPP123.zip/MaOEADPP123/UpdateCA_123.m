function [CA] = UpdateCA_123(CA,New,MaxSize,z,znad,DAobj,theta,Global)
% Update CA

%--------------------------------------------------------------------------
% The copyright of the PlatEMO belongs to the BIMK Group. You are free to
% use the PlatEMO for research purposes. All publications which use this
% platform or any code in the platform should acknowledge the use of
% "PlatEMO" and reference "Ye Tian, Ran Cheng, Xingyi Zhang, and Yaochu
% Jin, PlatEMO: A MATLAB Platform for Evolutionary Multi-Objective
% Optimization, 2016".
%--------------------------------------------------------------------------

% Copyright (c) 2016-2017 BIMK Group

    CA = [New,CA];
    ND = NDSort(CA.objs,1);
    CA = CA(ND==1);
    CAObj=CA.objs;
    [~,ia,~] = unique(CAObj,'rows');
     CA = CA(ia);

    N  = length(CA);
    if N <= MaxSize
        return;
    end
    
    %fprintf('gen=%d',Global.gen);
    
    CAObj=CA.objs;
    CAObj2 = (CAObj-repmat(z,N,1))./(repmat(znad,N,1)-repmat(z,N,1));
    nad=max(DAobj)+1E-6;
    nn=sum((nad-CAObj)<0,2);
    [N1,M]=size(DAobj);
    DAobj = (DAobj-repmat(z,N1,1))./(repmat(znad,N1,1)-repmat(z,N1,1));

    big=max(sqrt(sum(DAobj.^2,2)))+1E-6;
    nbig=sqrt(sum(CAObj2.^2,2))>big;
    nn=nn+nbig;

   
    D = pdist2(CAObj2,CAObj2,'cosine');

    D(1:size(D,1)+1:end) = 0;

    H=(1-theta)*exp(-D);

    value=(sum((CAObj2).^2,2));

    value(nn==0)=min(value)/2;
    value=value/max(value);
    L=value*value';
    H=H./L; 
    L = decompose_kernel(H);
    %Choose = sample_dpp_orginal(L,MaxSize);
    Choose = sample_dpp(L,MaxSize);
    CA = CA(Choose);

end