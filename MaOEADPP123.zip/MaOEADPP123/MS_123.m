function [ParentC] = MS_123(CA,DA,N,z,znad)
% The mating selection of Two_Arch2

%--------------------------------------------------------------------------
% The copyright of the PlatEMO belongs to the BIMK Group. You are free to
% use the PlatEMO for research purposes. All publications which use this
% platform or any code in the platform should acknowledge the use of
% "PlatEMO" and reference "Ye Tian, Ran Cheng, Xingyi Zhang, and Yaochu
% Jin, PlatEMO: A MATLAB Platform for Evolutionary Multi-Objective
% Optimization, 2016".
%--------------------------------------------------------------------------

% Copyright (c) 2016-2017 BIMK Group
% 

    EA=[CA,DA];
%     ND = NDSort(EA.objs,1);
%     EA = EA(ND==1);
    N2=length(CA);
    CAObj=EA.objs;
    [N1,M]=size(CAObj);
    CAObj2 = (CAObj-repmat(z,N1,1))./(repmat(znad,N1,1)-repmat(z,N1,1));
     [~,cc]=max(CAObj2);
    D = pdist2(CAObj2,CAObj2,'cosine');
    D=D+eye(N1);
    [cos,mincos]=min(D);
    CAO=sum(CAObj2.^2,2);
    minCAO=CAO(mincos);
    ch=(minCAO-CAO)>0;
    ch3=(1-ch).*mincos'+(ch).*(1:N1)';
    cos=1-cos;
    cos=(cos-min(cos))./repmat((max(cos)-min(cos)),1,N1);
 ParentC=[];
 for i=1:1:2*N
    k=randi(N1);
 if rand<cos(k)
       ParentC=[ParentC,EA(ch3(k))];
   else
       ParentC=[ParentC,EA(k)];
 end
 end

end